# AutoWebCast

Ứng dụng Android viết bằng Kotlin, hiển thị trình duyệt web (YouTube, Twitch, ...) lên màn hình xe qua Android Auto.

## Build APK trên GitHub

1. Tạo repository mới, đẩy toàn bộ nội dung thư mục này lên nhánh `main`.
2. Vào tab **Actions**, workflow **Build Android APK** sẽ tự chạy.
3. Khi xong, tải file APK ở mục **Artifacts** và cài lên điện thoại.

## Bật Android Auto để chạy app

App không có trên Google Play nên cần cài thủ công:

1. Cài APK lên điện thoại.
2. Mở **Android Auto** > Cài đặt > chạm 10 lần vào dòng **Phiên bản** > xác nhận bật chế độ nhà phát triển.
3. Menu ba chấm > **Cài đặt nhà phát triển** > bật **Nguồn không xác định**.
4. Kết nối điện thoại với xe, mở **AutoWebCast** trong danh sách ứng dụng trên màn hình xe.

## Cách dùng

- Trên màn hình xe: 4 nút YouTube, Quay lại, Trang kế tiếp, Tải lại trên thanh hệ thống. Chạm và cuộn trực tiếp lên trang.
- Tìm bằng giọng nói: chạm nút **micro tròn** nằm ngay trên trang (góc dưới bên phải) rồi nói từ khoá, app tìm trên YouTube. Lần đầu sẽ có hộp thoại xin quyền micro hiện trên điện thoại (cần mở khoá điện thoại để cấp).
- Nguồn âm thanh: ưu tiên **micro của xe** (cần Android 13 trở lên, Android Auto đủ mới và dịch vụ nhận diện giọng nói hỗ trợ nguồn âm thanh ngoài). Nếu không đáp ứng, app tự chuyển sang micro điện thoại; dòng trạng thái trên màn hình xe cho biết đang dùng micro nào.
- Trên điện thoại: mở app AutoWebCast để nhập địa chỉ, bấm biểu tượng micro cạnh ô nhập, hoặc chọn trang nhanh.

## Lưu ý

- Chỉ dùng khi xe đã dừng hẳn.
- Cảm ứng chỉ hoạt động với xe có màn hình cảm ứng.
- Google có thể chặn đăng nhập tài khoản trong WebView; nhiều nội dung có bản quyền (DRM) như Netflix sẽ không phát được.
- Dự án chưa được thử trên xe thật; xem `PROJECT_STRUCTURE.md` để nắm cấu trúc code.
