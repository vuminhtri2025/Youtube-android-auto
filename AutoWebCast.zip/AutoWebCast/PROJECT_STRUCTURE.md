# Sơ đồ dự án AutoWebCast

Ứng dụng Android (Kotlin) hiển thị trình duyệt web (YouTube, Twitch...) lên màn hình Android Auto.

## Cây thư mục

```
AutoWebCast/
├── .github/
│   └── workflows/
│       └── build.yml                  # GitHub Actions: build APK
├── app/
│   ├── build.gradle.kts               # Cấu hình module app + dependencies
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml        # Khai báo Activity, CarAppService, quyền
│       ├── java/com/autowebcast/
│       │   ├── MainActivity.kt        # Giao diện trên điện thoại
│       │   ├── CarBrowser.kt          # Trạng thái dùng chung (URL, danh sách trang, tìm YouTube)
│       │   ├── VoiceSearch.kt         # Nhận diện giọng nói (micro xe qua CarAudioRecord, dự phòng micro điện thoại)
│       │   └── car/
│       │       ├── CarWebService.kt   # CarAppService - điểm vào Android Auto
│       │       ├── WebSession.kt      # Session của Android Auto
│       │       ├── WebScreen.kt       # NavigationTemplate + 4 nút điều khiển
│       │       ├── CarRenderer.kt     # Surface -> VirtualDisplay, chuyển cảm ứng
│       │       └── WebPresentation.kt # Cửa sổ chứa WebView + nút micro nổi + dòng trạng thái
│       └── res/
│           ├── drawable/              # ic_launcher, ic_play, ic_back, ic_next, ic_refresh, ic_mic
│           ├── layout/activity_main.xml
│           ├── values/                # strings, colors, themes
│           └── xml/automotive_app_desc.xml
├── build.gradle.kts                   # Plugin AGP + Kotlin
├── settings.gradle.kts
├── gradle.properties
├── .gitignore
├── PROJECT_STRUCTURE.md               # File này
└── README.md
```

## Luồng hoạt động

```mermaid
flowchart LR
    A[Android Auto host] -->|bind| B[CarWebService]
    B --> C[WebSession]
    C --> D[WebScreen<br/>NavigationTemplate]
    D -->|setSurfaceCallback| E[CarRenderer]
    A -->|Surface + cảm ứng| E
    E -->|createVirtualDisplay| F[VirtualDisplay]
    F --> G[WebPresentation<br/>WebView]
    H[MainActivity<br/>trên điện thoại] -->|CarBrowser.open| E
    D -->|nút YouTube/Back/Next/Reload| E
    G -->|nút micro vẽ trong trang| E
    E -->|onMicClick| D
    D --> V[VoiceSearch<br/>CarAudioRecord = micro xe]
    H -->|nút micro| V2[VoiceSearch<br/>micro điện thoại]
    V2 -->|CarBrowser.search| E
    V -->|CarBrowser.search| E
```

## Thành phần chính

| File | Vai trò |
|------|---------|
| `CarWebService` | Dịch vụ để Android Auto kết nối vào app |
| `WebScreen` | Màn hình dạng điều hướng để xe cấp Surface; có 4 nút trên thanh hệ thống: YouTube, Quay lại, Trang kế tiếp, Tải lại; xử lý quyền micro và kết quả giọng nói |
| `VoiceSearch` | Đọc micro xe bằng `CarAudioRecord`, đưa vào `SpeechRecognizer` qua `EXTRA_AUDIO_SOURCE`; tự chuyển sang micro điện thoại nếu không hỗ trợ |
| `CarRenderer` | Nhận Surface của xe, tạo VirtualDisplay, đẩy cú chạm/cuộn vào WebView |
| `WebPresentation` | Chứa WebView (JS, cookie, video toàn màn hình) |
| `CarBrowser` | Lưu URL hiện tại, danh sách trang nhanh, điều khiển từ điện thoại |
| `MainActivity` | Nhập URL, chọn trang nhanh, xem hướng dẫn |

## Quy trình build

1. Đẩy toàn bộ thư mục lên GitHub (nhánh `main`).
2. Tab **Actions** > workflow **Build Android APK** tự chạy (hoặc chọn *Run workflow*).
3. Tải file `AutoWebCast-debug-apk` ở phần **Artifacts** khi chạy xong.
