# Quy tắc ProGuard/R8 (hiện tại minify đang tắt).
-keep class androidx.car.app.** { *; }
