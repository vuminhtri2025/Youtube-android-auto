package com.autowebcast.car

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.autowebcast.CarBrowser
import com.autowebcast.R

/**
 * Cửa sổ chứa WebView, hiển thị trên VirtualDisplay (được đẩy lên màn hình xe).
 * Có nút micro nổi ở góc dưới bên phải và dòng trạng thái giọng nói ở trên cùng.
 */
class WebPresentation(outerContext: Context, display: Display) :
    Presentation(outerContext, display) {

    /** Được gọi khi người dùng chạm nút micro trên màn hình. */
    var onMicClick: (() -> Unit)? = null

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var micButton: ImageButton
    private lateinit var statusView: TextView
    private val micBackground = GradientDrawable()
    private val uiHandler = Handler(Looper.getMainLooper())
    private val hideStatus = Runnable { statusView.visibility = View.GONE }
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)

        root = FrameLayout(context)
        root.setBackgroundColor(Color.BLACK)

        webView = WebView(context)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = DESKTOP_USER_AGENT
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (!url.isNullOrEmpty()) CarBrowser.currentUrl = url
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                webView.visibility = View.GONE
                micButton.visibility = View.GONE
                root.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }

        root.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        addVoiceOverlay()
        setContentView(root)
        webView.loadUrl(CarBrowser.currentUrl)
    }

    /** Nút micro tròn (góc dưới phải) và dòng trạng thái (trên cùng, giữa). */
    private fun addVoiceOverlay() {
        val density = context.resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        micBackground.shape = GradientDrawable.OVAL
        micBackground.setColor(MIC_COLOR_IDLE)

        micButton = ImageButton(context)
        micButton.setImageResource(R.drawable.ic_mic)
        micButton.background = micBackground
        micButton.scaleType = ImageView.ScaleType.CENTER_INSIDE
        micButton.setPadding(dp(20), dp(20), dp(20), dp(20))
        micButton.elevation = dp(6).toFloat()
        micButton.contentDescription = context.getString(R.string.btn_mic)
        micButton.setOnClickListener { onMicClick?.invoke() }

        val micParams = FrameLayout.LayoutParams(
            dp(80), dp(80), Gravity.BOTTOM or Gravity.END
        )
        micParams.setMargins(0, 0, dp(24), dp(24))
        root.addView(micButton, micParams)

        val statusBackground = GradientDrawable()
        statusBackground.cornerRadius = dp(24).toFloat()
        statusBackground.setColor(Color.parseColor("#CC000000"))

        statusView = TextView(context)
        statusView.setTextColor(Color.WHITE)
        statusView.textSize = 20f
        statusView.setPadding(dp(24), dp(12), dp(24), dp(12))
        statusView.background = statusBackground
        statusView.visibility = View.GONE

        val statusParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        )
        statusParams.topMargin = dp(24)
        root.addView(statusView, statusParams)
    }

    /** Hiện dòng trạng thái; durationMs = 0 nghĩa là giữ cho đến khi gọi lại. */
    fun showStatus(text: String?, durationMs: Long = 0L) {
        uiHandler.removeCallbacks(hideStatus)
        if (text.isNullOrEmpty()) {
            statusView.visibility = View.GONE
            return
        }
        statusView.text = text
        statusView.visibility = View.VISIBLE
        if (durationMs > 0) uiHandler.postDelayed(hideStatus, durationMs)
    }

    /** Đổi màu nút micro khi đang nghe. */
    fun setListening(listening: Boolean) {
        micBackground.setColor(if (listening) MIC_COLOR_LISTENING else MIC_COLOR_IDLE)
    }

    fun dispatchTouch(event: MotionEvent) {
        root.dispatchTouchEvent(event)
    }

    fun scrollBy(dx: Int, dy: Int) {
        webView.scrollBy(dx, dy)
    }

    fun fling(vx: Int, vy: Int) {
        webView.flingScroll(vx, vy)
    }

    fun loadUrl(url: String) {
        hideCustomView()
        webView.loadUrl(url)
    }

    fun goBack() {
        if (customView != null) {
            hideCustomView()
        } else if (webView.canGoBack()) {
            webView.goBack()
        }
    }

    fun reload() {
        webView.reload()
    }

    fun shutdown() {
        uiHandler.removeCallbacksAndMessages(null)
        hideCustomView()
        root.removeAllViews()
        webView.stopLoading()
        webView.destroy()
        dismiss()
    }

    private fun hideCustomView() {
        val view = customView ?: return
        root.removeView(view)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        webView.visibility = View.VISIBLE
        micButton.visibility = View.VISIBLE
    }

    private companion object {
        val MIC_COLOR_IDLE: Int = Color.parseColor("#C62828")
        val MIC_COLOR_LISTENING: Int = Color.parseColor("#2E7D32")
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}
