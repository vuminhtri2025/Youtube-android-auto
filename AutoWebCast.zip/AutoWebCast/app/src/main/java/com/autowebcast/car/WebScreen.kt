package com.autowebcast.car

import android.Manifest
import android.content.pm.PackageManager
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.autowebcast.CarBrowser
import com.autowebcast.R
import com.autowebcast.VoiceSearch

/**
 * Màn hình duy nhất trên xe. Dùng NavigationTemplate để được cấp Surface,
 * rồi CarRenderer vẽ WebView lên Surface đó.
 * Nút micro được vẽ ngay trong trang (WebPresentation), không nằm trên thanh hệ thống.
 */
class WebScreen(ctx: CarContext) : Screen(ctx) {

    private val renderer = CarRenderer(ctx)

    private val voice = VoiceSearch(ctx, object : VoiceSearch.Listener {
        override fun onListening(usingCarMic: Boolean) {
            renderer.setListening(true)
            renderer.showVoiceStatus(
                carContext.getString(
                    if (usingCarMic) R.string.voice_listening_car
                    else R.string.voice_listening_phone
                )
            )
        }

        override fun onResult(text: String) {
            renderer.setListening(false)
            renderer.showVoiceStatus(
                carContext.getString(R.string.voice_searching, text), STATUS_MS
            )
            CarBrowser.search(text)
        }

        override fun onError(message: String) {
            renderer.setListening(false)
            renderer.showVoiceStatus(message, STATUS_MS)
        }
    }, ctx)

    init {
        renderer.onMicClick = { onMicClick() }
        lifecycle.addObserver(LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_CREATE ->
                    carContext.getCarService(AppManager::class.java).setSurfaceCallback(renderer)
                Lifecycle.Event.ON_DESTROY -> {
                    voice.stop()
                    carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
                    renderer.release()
                }
                else -> Unit
            }
        })
    }

    override fun onGetTemplate(): Template {
        val strip = ActionStrip.Builder()
            .addAction(action(R.drawable.ic_play) { CarBrowser.open(CarBrowser.HOME) })
            .addAction(action(R.drawable.ic_back) { renderer.goBack() })
            .addAction(action(R.drawable.ic_next) { CarBrowser.nextSite() })
            .addAction(action(R.drawable.ic_refresh) { renderer.reload() })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(strip)
            .build()
    }

    private fun onMicClick() {
        val permission = Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(carContext, permission) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            voice.start()
        } else {
            // Hiện hộp thoại xin quyền micro trên điện thoại
            carContext.requestPermissions(listOf(permission)) { granted, _ ->
                if (granted.contains(permission)) {
                    voice.start()
                } else {
                    renderer.showVoiceStatus(
                        carContext.getString(R.string.voice_no_permission), STATUS_MS
                    )
                }
            }
        }
    }

    private fun action(iconRes: Int, onClick: () -> Unit): Action {
        val icon = CarIcon.Builder(IconCompat.createWithResource(carContext, iconRes))
            .setTint(CarColor.DEFAULT)
            .build()
        return Action.Builder()
            .setIcon(icon)
            .setOnClickListener { onClick() }
            .build()
    }

    private companion object {
        const val STATUS_MS = 3000L
    }
}
