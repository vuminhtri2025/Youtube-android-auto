package com.autowebcast.car

import android.content.Intent
import androidx.car.app.Screen
import androidx.car.app.Session

class WebSession : Session() {

    override fun onCreateScreen(intent: Intent): Screen = WebScreen(carContext)
}
