package com.autowebcast

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvStatus: TextView
    private lateinit var etUrl: EditText
    private lateinit var voice: VoiceSearch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        etUrl = findViewById(R.id.etUrl)
        etUrl.setText(CarBrowser.currentUrl)

        voice = VoiceSearch(this, object : VoiceSearch.Listener {
            override fun onListening(usingCarMic: Boolean) {
                toast(getString(R.string.voice_listening))
            }

            override fun onResult(text: String) {
                toast(getString(R.string.voice_searching, text))
                CarBrowser.search(text)
                etUrl.setText(CarBrowser.currentUrl)
            }

            override fun onError(message: String) {
                toast(message)
            }
        })

        findViewById<Button>(R.id.btnGo).setOnClickListener {
            go(etUrl.text.toString())
        }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener {
            startVoice()
        }
        etUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                go(etUrl.text.toString())
                true
            } else {
                false
            }
        }

        val box = findViewById<LinearLayout>(R.id.llSites)
        CarBrowser.sites.forEach { site ->
            val button = Button(this)
            button.text = site.name
            button.setOnClickListener { go(site.url) }
            box.addView(button)
        }
    }

    override fun onResume() {
        super.onResume()
        tvStatus.setText(
            if (CarBrowser.carConnected) R.string.status_connected
            else R.string.status_disconnected
        )
    }

    override fun onDestroy() {
        voice.stop()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                voice.start()
            } else {
                toast(getString(R.string.voice_no_permission))
            }
        }
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            voice.start()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
        }
    }

    private fun go(input: String) {
        CarBrowser.open(input)
        etUrl.setText(CarBrowser.currentUrl)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val REQUEST_AUDIO = 1001
    }
}
