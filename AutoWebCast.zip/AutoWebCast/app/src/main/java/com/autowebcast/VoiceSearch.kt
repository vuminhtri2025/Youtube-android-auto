package com.autowebcast

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.car.app.CarContext
import androidx.car.app.media.CarAudioRecord
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Tìm kiếm bằng giọng nói.
 *
 * - Trên xe (truyền carContext): ưu tiên đọc âm thanh từ micro của xe qua CarAudioRecord,
 *   đẩy vào SpeechRecognizer bằng EXTRA_AUDIO_SOURCE (cần Android 13+ và host Car API 5+).
 *   Nếu thiết bị/host/dịch vụ nhận diện không hỗ trợ thì tự chuyển sang micro điện thoại.
 * - Trên điện thoại (không truyền carContext): dùng micro điện thoại.
 *
 * Phải gọi trên main thread và cần quyền RECORD_AUDIO đã được cấp.
 */
class VoiceSearch(
    private val context: Context,
    private val listener: Listener,
    private val carContext: CarContext? = null
) {

    interface Listener {
        fun onListening(usingCarMic: Boolean)
        fun onResult(text: String)
        fun onError(message: String)
    }

    private var recognizer: SpeechRecognizer? = null
    private var carMic: CarMicStream? = null

    fun start() {
        stop()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onError(context.getString(R.string.voice_unavailable))
            return
        }
        if (canUseCarMic() && startRecognizer(useCarMic = true)) return
        startRecognizer(useCarMic = false)
    }

    fun stop() {
        carMic?.stop()
        carMic = null
        recognizer?.destroy()
        recognizer = null
    }

    private fun canUseCarMic(): Boolean {
        val car = carContext ?: return false
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            car.carAppApiLevel >= MIN_CAR_API_FOR_MIC
    }

    /** Trả về false nếu không thể dùng micro xe (để chuyển sang micro điện thoại). */
    private fun startRecognizer(useCarMic: Boolean): Boolean {
        var pipe: Array<ParcelFileDescriptor>? = null
        var mic: CarMicStream? = null

        if (useCarMic) {
            val car = carContext ?: return false
            try {
                val created = ParcelFileDescriptor.createPipe()
                pipe = created
                val stream = CarMicStream(car, ParcelFileDescriptor.AutoCloseOutputStream(created[1]))
                if (!stream.prepare()) {
                    closeQuietly(created)
                    return false
                }
                mic = stream
            } catch (e: Exception) {
                Log.w(TAG, "Không mở được micro xe", e)
                pipe?.let { closeQuietly(it) }
                return false
            }
        }

        val speech = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = speech
        carMic = mic
        speech.setRecognitionListener(buildListener(useCarMic))

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            if (pipe != null) {
                // Âm thanh PCM 16-bit, mono, 16 kHz đọc từ micro xe
                putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0])
                putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                putExtra(
                    RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                putExtra(
                    RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,
                    CAR_MIC_SAMPLE_RATE
                )
            }
        }

        listener.onListening(useCarMic)
        speech.startListening(intent)
        pipe?.get(0)?.close() // dịch vụ nhận diện đã giữ bản sao đầu đọc
        mic?.start()
        return true
    }

    private fun buildListener(usedCarMic: Boolean) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onPartialResults(partialResults: Bundle?) = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit

        override fun onEndOfSpeech() {
            carMic?.stop()
        }

        override fun onError(error: Int) {
            stop()
            if (usedCarMic && isEngineProblem(error)) {
                // Dịch vụ nhận diện không nhận nguồn âm thanh ngoài -> dùng micro điện thoại
                startRecognizer(useCarMic = false)
                return
            }
            listener.onError(messageFor(error))
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
            stop()
            if (text.isNullOrEmpty()) {
                listener.onError(context.getString(R.string.voice_no_match))
            } else {
                listener.onResult(text)
            }
        }
    }

    private fun isEngineProblem(error: Int): Boolean = when (error) {
        SpeechRecognizer.ERROR_AUDIO,
        SpeechRecognizer.ERROR_CLIENT,
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> true
        else -> false
    }

    private fun messageFor(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> context.getString(R.string.voice_no_match)
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            context.getString(R.string.voice_no_permission)
        else -> context.getString(R.string.voice_error)
    }

    private fun closeQuietly(pipe: Array<ParcelFileDescriptor>) {
        pipe.forEach {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Đọc âm thanh từ micro xe (CarAudioRecord) trên luồng nền và ghi vào đường ống
     * mà SpeechRecognizer đang đọc. Giữ audio focus trong lúc ghi.
     */
    private class CarMicStream(
        private val carContext: CarContext,
        private val out: ParcelFileDescriptor.AutoCloseOutputStream
    ) {
        private val running = AtomicBoolean(false)
        private val closed = AtomicBoolean(false)
        private val audioManager = carContext.getSystemService(AudioManager::class.java)
        private var record: CarAudioRecord? = null
        private var focusRequest: AudioFocusRequest? = null
        private var started = false

        fun prepare(): Boolean {
            val manager = audioManager ?: return false
            val attributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .build()
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(attributes)
                .setOnAudioFocusChangeListener { state ->
                    if (state == AudioManager.AUDIOFOCUS_LOSS) stop()
                }
                .build()
            if (manager.requestAudioFocus(request) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                return false
            }
            focusRequest = request
            record = CarAudioRecord.create(carContext)
            return true
        }

        fun start() {
            val rec = record ?: return
            if (!running.compareAndSet(false, true)) return
            started = true
            Thread({ pump(rec) }, "AutoWebCast-carmic").start()
        }

        fun stop() {
            running.set(false)
            if (!started) cleanup(null)
        }

        private fun pump(rec: CarAudioRecord) {
            val buffer = ByteArray(CarAudioRecord.AUDIO_CONTENT_BUFFER_SIZE)
            val deadline = SystemClock.elapsedRealtime() + MAX_RECORD_MS
            try {
                rec.startRecording()
                while (running.get() && SystemClock.elapsedRealtime() < deadline) {
                    val count = rec.read(buffer, 0, buffer.size)
                    if (count < 0) break
                    if (count > 0) out.write(buffer, 0, count)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Lỗi khi đọc micro xe", e)
            } finally {
                running.set(false)
                cleanup(rec)
            }
        }

        private fun cleanup(rec: CarAudioRecord?) {
            if (!closed.compareAndSet(false, true)) return
            try {
                rec?.stopRecording()
            } catch (_: Exception) {
            }
            try {
                out.close() // báo EOF để bộ nhận diện chốt kết quả
            } catch (_: Exception) {
            }
            focusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
        }
    }

    private companion object {
        const val TAG = "AutoWebCast"
        const val MIN_CAR_API_FOR_MIC = 5
        const val CAR_MIC_SAMPLE_RATE = 16000
        const val MAX_RECORD_MS = 10_000L
    }
}
