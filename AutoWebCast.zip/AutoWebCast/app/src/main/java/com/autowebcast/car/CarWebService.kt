package com.autowebcast.car

import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator

/**
 * Điểm vào của Android Auto. Cho phép mọi host vì app này chỉ dùng cài thủ công
 * (Android Auto bật "Nguồn không xác định").
 */
class CarWebService : CarAppService() {

    override fun createHostValidator(): HostValidator =
        HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = WebSession()
}
