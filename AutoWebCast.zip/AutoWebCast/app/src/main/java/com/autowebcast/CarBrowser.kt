package com.autowebcast

import android.net.Uri

/**
 * Trạng thái dùng chung giữa màn hình điện thoại (MainActivity)
 * và màn hình xe (car/*). Tất cả chạy trên main thread.
 */
object CarBrowser {

    data class Site(val name: String, val url: String)

    /** Phần điều khiển trình duyệt đang hiển thị trên màn hình xe. */
    interface Controller {
        fun loadUrl(url: String)
        fun goBack()
        fun reload()
    }

    const val HOME = "https://www.youtube.com"

    val sites = listOf(
        Site("YouTube", HOME),
        Site("YouTube Music", "https://music.youtube.com"),
        Site("Twitch", "https://www.twitch.tv"),
        Site("Dailymotion", "https://www.dailymotion.com"),
        Site("Google", "https://www.google.com")
    )

    @Volatile
    var currentUrl: String = HOME

    @Volatile
    var carConnected: Boolean = false

    var controller: Controller? = null

    private var siteIndex = 0

    fun open(input: String) {
        val url = normalize(input)
        currentUrl = url
        controller?.loadUrl(url)
    }

    /** Tìm kiếm từ khoá trên YouTube (dùng cho tìm bằng giọng nói). */
    fun search(query: String) {
        val text = query.trim()
        if (text.isEmpty()) return
        open("https://www.youtube.com/results?search_query=" + Uri.encode(text))
    }

    fun nextSite() {
        siteIndex = (siteIndex + 1) % sites.size
        open(sites[siteIndex].url)
    }

    fun normalize(raw: String): String {
        val text = raw.trim()
        return when {
            text.isEmpty() -> HOME
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains(' ') || !text.contains('.') ->
                "https://www.google.com/search?q=" + Uri.encode(text)
            else -> "https://$text"
        }
    }
}
