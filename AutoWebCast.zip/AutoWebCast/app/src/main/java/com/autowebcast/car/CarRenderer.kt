package com.autowebcast.car

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.MotionEvent
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import com.autowebcast.CarBrowser

/**
 * Nhận Surface từ màn hình xe, tạo VirtualDisplay lên Surface đó
 * và hiển thị WebPresentation (chứa WebView) trên VirtualDisplay.
 * Đồng thời chuyển thao tác chạm của xe vào WebView.
 */
class CarRenderer(private val context: Context) : SurfaceCallback, CarBrowser.Controller {

    private val handler = Handler(Looper.getMainLooper())
    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: WebPresentation? = null

    /** Được gọi khi người dùng chạm nút micro vẽ trong trang web trên màn hình xe. */
    var onMicClick: (() -> Unit)? = null

    // ---- SurfaceCallback ----

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        release()

        val surface = surfaceContainer.surface ?: return
        val width = surfaceContainer.width
        val height = surfaceContainer.height
        val dpi = if (surfaceContainer.dpi > 0) surfaceContainer.dpi else 160
        if (width <= 0 || height <= 0) return

        try {
            val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION
            val display = displayManager.createVirtualDisplay(
                "AutoWebCast", width, height, dpi, surface, flags
            ) ?: return
            virtualDisplay = display

            val p = WebPresentation(context, display.display)
            p.onMicClick = { onMicClick?.invoke() }
            presentation = p
            p.show()

            CarBrowser.controller = this
            CarBrowser.carConnected = true
        } catch (e: Exception) {
            Log.e(TAG, "Không thể tạo màn hình ảo", e)
            release()
        }
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        release()
    }

    override fun onClick(x: Float, y: Float) {
        val p = presentation ?: return
        val downTime = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
        down.source = InputDevice.SOURCE_TOUCHSCREEN
        p.dispatchTouch(down)
        down.recycle()

        handler.postDelayed({
            val target = presentation ?: return@postDelayed
            val up = MotionEvent.obtain(
                downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0
            )
            up.source = InputDevice.SOURCE_TOUCHSCREEN
            target.dispatchTouch(up)
            up.recycle()
        }, TAP_DELAY_MS)
    }

    override fun onScroll(distanceX: Float, distanceY: Float) {
        presentation?.scrollBy(distanceX.toInt(), distanceY.toInt())
    }

    override fun onFling(velocityX: Float, velocityY: Float) {
        presentation?.fling(-velocityX.toInt(), -velocityY.toInt())
    }

    // ---- Giao diện giọng nói trong trang ----

    fun showVoiceStatus(text: String?, durationMs: Long = 0L) {
        presentation?.showStatus(text, durationMs)
    }

    fun setListening(listening: Boolean) {
        presentation?.setListening(listening)
    }

    // ---- CarBrowser.Controller ----

    override fun loadUrl(url: String) {
        presentation?.loadUrl(url)
    }

    override fun goBack() {
        presentation?.goBack()
    }

    override fun reload() {
        presentation?.reload()
    }

    // ---- Dọn dẹp ----

    fun release() {
        handler.removeCallbacksAndMessages(null)
        presentation?.let {
            try {
                it.shutdown()
            } catch (e: Exception) {
                Log.w(TAG, "Lỗi khi đóng presentation", e)
            }
        }
        presentation = null
        virtualDisplay?.release()
        virtualDisplay = null
        if (CarBrowser.controller === this) {
            CarBrowser.controller = null
        }
        CarBrowser.carConnected = false
    }

    private companion object {
        const val TAG = "AutoWebCast"
        const val TAP_DELAY_MS = 60L
    }
}
